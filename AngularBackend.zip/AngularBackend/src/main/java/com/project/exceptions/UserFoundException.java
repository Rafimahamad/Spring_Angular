package com.project.exceptions;

public class UserFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UserFoundException(String message) {
		super(message);

	}

	
}
