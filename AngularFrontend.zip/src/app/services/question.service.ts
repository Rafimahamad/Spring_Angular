import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Question } from '../classes/question';
import baseUrl from './help';

@Injectable({
  providedIn: 'root'
})
export class QuestionService {

  constructor(private httpClient:HttpClient) { }

  getAllQuestions():Observable<Object>{
    return this.httpClient.get(`${baseUrl}/question/allQueries`)
  }

  saveQuery(question:Question):Observable<Object>{
return this.httpClient.post(`${baseUrl}/question/saveQuery`,question);
  }


showQueryDetails(id:number):Observable<Object>{

  return this.httpClient.get(`${baseUrl}/question/${id}`);
}

findEmployeeByQid(id:number):Observable<Object>{
  return this.httpClient.get(`${baseUrl}/question/qemp/${id}`)
}

deleteQueryById(id:number):Observable<Object>{
  return this.httpClient.delete(`${baseUrl}/question/${id}`);
}

saveEditedQuery(qId:number,query:Question):Observable<Object>{
  return this.httpClient.put(`${baseUrl}/question/${qId}`,query);
}

getYourQueries():Observable<Object> {
  return this.httpClient.get(`${baseUrl}/question/getYourQueries`);
}

getUnREsolvedQueries():Observable<Object>{
  return this.httpClient.get(`${baseUrl}/admin/unResolved`)
}

}
