import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Employee } from '../classes/employee';
import baseUrl from './help';

@Injectable({
  providedIn: 'root'
})
export class EmployeeServiceService {


  constructor( private httpClient:HttpClient ) { }



  public registerEmployee(emp:Employee):Observable<Object>{
   console.log(emp);
   return this.httpClient.post(`${baseUrl}/user/`,emp);
   
  }


  public saveProfile(emp:Employee):Observable<Object>{
    return this.httpClient.post(`${baseUrl}/user/saveProfile`,emp);
  }


  public employeeList():Observable<Object>{
   
    return this.httpClient.get(`${baseUrl}/admin/empList`);
  }


  public changePassword(password:String):Observable<Object>{
   return this.httpClient.get(`${baseUrl}/user/changePassword/${password}`);
  }


public sendOtp(email:String):Observable<Object>{
  return this.httpClient.get(`${baseUrl}/forgot/sendOtp/${email}`)
}

public validateOtp(otp:number):Observable<Object>{
  return this.httpClient.get(`${baseUrl}/forgot/validateOtp/${otp}`);
}

public changeYourPassword(password:String):Observable<Object>{
  return this.httpClient.get(`${baseUrl}/forgot/changePassword/${password}`);
 }

 public requestToAdmin(email:String):Observable<Object>{
  return this.httpClient.get(`${baseUrl}/forgot/contactAdmin/${email}`);
 }


public blockEmployee(id:number):Observable<Object>{
return this.httpClient.get(`${baseUrl}/admin/block/${id}`);
}

public activateEmployee(id:number):Observable<Object>{
  return this.httpClient.get(`${baseUrl}/admin/activate/${id}`);
}


}
