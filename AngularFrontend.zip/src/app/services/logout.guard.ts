import { Injectable } from '@angular/core';
import {  CanDeactivate } from '@angular/router';
import { Observable } from 'rxjs';



export interface CanLogout{
  canExit: ()=>Observable<boolean> | Promise<boolean> | boolean;
}

@Injectable({
  providedIn: 'root'
})

export class LogoutGuard implements CanDeactivate<CanLogout> {
 canDeactivate( component : CanLogout){
return component.canExit ? component.canExit() :true;
 }
  
}
