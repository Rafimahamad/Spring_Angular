import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Answer } from '../classes/answer';
import baseUrl from './help';

@Injectable({
  providedIn: 'root'
})
export class AnswerService {

  constructor(private httpClient:HttpClient) { }


  public saveAnswer(answer:Answer,qId:number):Observable<Object>{
return this.httpClient.post(`${baseUrl}/question/saveReply/${qId}`,answer);
  }


public getAnsweredEmpByaId(aId:number):Observable<Object>{
  return this.httpClient.get(`${baseUrl}/answer/emp/${aId}`);
}


public getAnswereByaId(aId:number):Observable<Object>{
  return this.httpClient.get(`${baseUrl}/answer/${aId}`);
}


public deleteAnswerByaId(aId:number,qId:number):Observable<Object>{

  return this.httpClient.delete(`${baseUrl}/answer/${aId}/${qId}`);
}

}
