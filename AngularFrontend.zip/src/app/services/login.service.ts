import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import baseUrl from './help';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private httpClient:HttpClient) { }

  //generate token
public generateToken(login:any){
  return this.httpClient.post(`${baseUrl}/token`,login);
}

// store token in localStorage
public userLoggedIn(token:any){
  localStorage.setItem('token',token);
  console.log('from Login '+token);
  return true;
}


//check User is loggedin

public checkUserLoggedIn(){
  let tokenValid=localStorage.getItem('token');
  if(tokenValid==undefined || tokenValid=='' || tokenValid==null){
    return false;
  }
  else

  return true;
}


//get CurrentUser
public getCurrentUser(){
  return this.httpClient.get(`${baseUrl}/currentUser`);
}


// set User details in local storage 
public setEmployee(employee:any){
  localStorage.setItem('employee',JSON.stringify(employee));
}

public logout(){
  localStorage.removeItem('token');
  localStorage.removeItem('employee');
  window.location.reload();
  return true;
}


//get employee details
public getEmployee(){
 let validEmp= localStorage.getItem('employee');
 if(validEmp!=null){
  return JSON.parse(validEmp);
 }
 else{
  this.logout();
  return null;
 }
}


//get role

public getEmployeeRole(){
  let emp=this.getEmployee();
  return emp.role;
}


public getToken(){
  return localStorage.getItem('token');
}

}
