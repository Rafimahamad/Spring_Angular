import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ContactComponent } from './components/contact/contact.component';
import { PageNotfoundComponent } from './components/page-notfound/page-notfound.component';
import { AddQueryComponent } from './Pages/admin/add-query/add-query.component';
import { AdminDashboardComponent } from './Pages/admin/admin-dashboard/admin-dashboard.component';
import { AdminProfileComponent } from './Pages/admin/admin-profile/admin-profile.component';
import { AdminQueriesComponent } from './Pages/admin/admin-queries/admin-queries.component';
import { AdminSidebarComponent } from './Pages/admin/admin-sidebar/admin-sidebar.component';
import { AllQueriesComponent } from './Pages/admin/all-queries/all-queries.component';
import { AnswerDetailsComponent } from './Pages/admin/answer-details/answer-details.component';
import { EditQueryComponent } from './Pages/admin/edit-query/edit-query.component';
import { EmpListComponent } from './Pages/admin/emp-list/emp-list.component';
import { ReplyComponent } from './Pages/admin/reply/reply.component';
import { UnResolvedComponent } from './Pages/admin/un-resolved/un-resolved.component';
import { UpdateProfileComponent } from './Pages/admin/update-profile/update-profile.component';
import { ViewQueryComponent } from './Pages/admin/view-query/view-query.component';
import { ForgotPasswordComponent } from './Pages/forgot-password/forgot-password.component';
import { HomeComponent } from './Pages/home/home.component';
import { LoginComponent } from './Pages/login/login.component';
import { RegisterComponent } from './Pages/register/register.component';
import { SettingsComponent } from './Pages/settings/settings.component';
import { SignupComponent } from './Pages/signup/signup.component';
import { EditProfileComponent } from './Pages/user/edit-profile/edit-profile.component';
import { PostQueryComponent } from './Pages/user/post-query/post-query.component';
import { QueriesComponent } from './Pages/user/queries/queries.component';
import { RespondComponent } from './Pages/user/respond/respond.component';
import { SeeAnswerComponent } from './Pages/user/see-answer/see-answer.component';
import { SeeQueryComponent } from './Pages/user/see-query/see-query.component';
import { UpdateQueryComponent } from './Pages/user/update-query/update-query.component';
import { UserDashboardComponent } from './Pages/user/user-dashboard/user-dashboard.component';
import { UserProfileComponent } from './Pages/user/user-profile/user-profile.component';
import { UserQueriesComponent } from './Pages/user/user-queries/user-queries.component';
import { UserSidebarComponent } from './Pages/user/user-sidebar/user-sidebar.component';
import { AdminGuard } from './services/admin.guard';
import { UserGuard } from './services/user.guard';

const routes: Routes = [
  { path:'',component:HomeComponent, pathMatch:'full' },

  { path:'login',component:LoginComponent,pathMatch:'full' },

  { path:'signup',component:SignupComponent,pathMatch:'full' },

  { path:'register',component:RegisterComponent,pathMatch:'full'},
  { path:'forgot',component:ForgotPasswordComponent,pathMatch:'full'},
  { path:'contact',component:ContactComponent,pathMatch:'full'},



  {
   path:'adminDashboard',
   component:AdminDashboardComponent,
   canActivate:[AdminGuard],
   children: [
              { path:'profile',component:AdminProfileComponent },
              { path:'updateProfile',component:UpdateProfileComponent },
              { path:'addQuery',component:AddQueryComponent },
              { path:'editQuery/:qid',component:EditQueryComponent },
              { path:'unResolve',component:UnResolvedComponent },
              { path:'allQueries',component:AllQueriesComponent },
              { path:'adminQueries',component:AdminQueriesComponent },
              { path:'settings',component:SettingsComponent },
              { path:'empList',component:EmpListComponent },
              { path:'viewQuery/:qid',component:ViewQueryComponent },
              { path:'reply/:qid',component:ReplyComponent },
              { path:'answerDetails/:aid/:qid',component:AnswerDetailsComponent },
          




          
            ]

}

,
{
  path:'userDashboard',
  component:UserDashboardComponent,
  canActivate:[UserGuard],
  children: [
             { path:'profile',component:UserProfileComponent },
             {path:'editProfile',component:EditProfileComponent},
             {path:'addQuery',component:PostQueryComponent},
             {path:'editQuery/:qid',component:UpdateQueryComponent},
             {path:'allQueries',component:QueriesComponent},
             {path:'userQueries',component:UserQueriesComponent},
             {path:'reply/:qid',component:RespondComponent},
             { path:'viewQuery/:qid',component:SeeQueryComponent },
             { path:'answerDetails/:aid/:qid',component:SeeAnswerComponent },
             { path:'settings',component:SettingsComponent },



           ]

},
{
  path:'**',component:PageNotfoundComponent
}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const MyRoutings =[

  HomeComponent,
  LoginComponent,
  RegisterComponent,
  AdminDashboardComponent,
AdminProfileComponent,
AdminSidebarComponent,
UserDashboardComponent,
UserProfileComponent,
UserSidebarComponent,
UpdateProfileComponent,
AddQueryComponent,
EditQueryComponent,
UnResolvedComponent,
AllQueriesComponent,
AdminQueriesComponent,
SettingsComponent,
EmpListComponent,
ViewQueryComponent,
ReplyComponent,
AnswerDetailsComponent,
ForgotPasswordComponent,
ContactComponent,
PageNotfoundComponent,
EditProfileComponent,
PostQueryComponent,
UpdateQueryComponent,
QueriesComponent,
UserQueriesComponent,
UserQueriesComponent,
RespondComponent,
SeeQueryComponent,
SeeAnswerComponent,

]