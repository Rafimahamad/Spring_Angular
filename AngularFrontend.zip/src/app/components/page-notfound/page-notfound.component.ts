import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from 'src/app/classes/employee';
import { LoginService } from 'src/app/services/login.service';

@Component({
  selector: 'app-page-notfound',
  templateUrl: './page-notfound.component.html',
  styleUrls: ['./page-notfound.component.css']
})
export class PageNotfoundComponent implements OnInit {
user:Employee;
errMsg:String;
  constructor( private router:Router,private loginService:LoginService) { }

  ngOnInit(): void {
    this.errMsg=this.router.url;
 this.loginService.getCurrentUser().subscribe(
  (data:any)=>this.user=data
 )
  }

  gotoHome(){
    if(this.user==null){
      this.router.navigate(['/']);
    }
    else if(this.user.role=='ROLE_USER')
    {
      this.router.navigate(['/userDashboard/allQueries']);
    }
    else if(this.user.role=='ROLE_ADMIN')
    {
      this.router.navigate(['/adminDashboard/allQueries']);
    }
    else{
      this.router.navigate(['/']);
    }
  }
}
