import { Component, OnInit } from '@angular/core';
import { EmployeeServiceService } from 'src/app/services/employee-service.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {
email:String;
  constructor(private empService:EmployeeServiceService) { }

  ngOnInit(): void {
  }

contactForm(){
this.empService.requestToAdmin(this.email).subscribe(
  (data:any)=>{
    Swal.fire('your request sent successfully to admin','done','success');
  },
  (error)=>{
    if(error.status==400){
    Swal.fire('you are the active user','active','info');
    }
    else{
      Swal.fire('Something went wrong !','email id not exist','error');
    }
  }
)
}
}
