import { Component, OnInit } from '@angular/core';
import { LoginService } from 'src/app/services/login.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {



  constructor( private loginService:LoginService) { }
user:any;
isLoggedIn=false;

  ngOnInit(): void {
   this.loginService.getCurrentUser().subscribe(
    (data:any)=>{
      this.user=data;

    }
   )
this.isLoggedIn=this.loginService.checkUserLoggedIn();

  }

logout(){
 if(confirm("do you want to logout")){
 this.loginService.logout();
 }
 else{
  console.log('not loggedout');
 }
}

gotofresh(){
  window.location.reload();
}

}
