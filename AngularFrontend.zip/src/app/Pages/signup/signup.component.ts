import { Component, OnInit } from '@angular/core';
import { FormBuilder,  FormGroup, Validators } from '@angular/forms';
import { Employee } from 'src/app/classes/employee';
import { EmployeeServiceService } from 'src/app/services/employee-service.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})


export class SignupComponent implements OnInit {

employee:Employee=new Employee();

constructor( private empService:EmployeeServiceService,private fb :FormBuilder) { }

  public signupForm :FormGroup ;

    // public firstName: String="";
    // public lastName : String='';
    // public role: String='';
    // public email: String='';
    // public doj: String='';
    // public gender: String='';
    // public phoneNo: String='';
    // public designation: String='';
    // public  password: String='';
    // public profile:String='';

  ngOnInit(): void {
    let  validations = {
      firstName:[ '',Validators.compose([Validators.required , Validators.minLength(3) ])],
      lastName:['',Validators.compose([Validators.required , Validators.minLength(3)]) ] ,
      email:['',Validators.compose([Validators.required , Validators.minLength(7),Validators.pattern("^[a-z][a-z0-9+_.-]+@gmail.com+$")])  ] ,
      phoneNo:['',Validators.compose([Validators.required ,Validators.minLength(10) ,Validators.pattern("[6-9]{1}[0-9]{9}")])] ,
     
      doj: ['',Validators.required  ] ,
      
      password:['',Validators.compose([Validators.required,Validators.minLength(6)])],
   
    }

 this.signupForm=this.fb.group(validations);
  }


 saveEmployee(employee:Employee){
   alert('submitted');
   console.log(employee)
      }
}





