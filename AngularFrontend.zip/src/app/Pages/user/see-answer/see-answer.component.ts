import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Answer } from 'src/app/classes/answer';
import { Employee } from 'src/app/classes/employee';
import { Question } from 'src/app/classes/question';
import { AnswerService } from 'src/app/services/answer.service';
import { LoginService } from 'src/app/services/login.service';
import { QuestionService } from 'src/app/services/question.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-see-answer',
  templateUrl: './see-answer.component.html',
  styleUrls: ['./see-answer.component.css']
})
export class SeeAnswerComponent implements OnInit {


  constructor( private aroute:ActivatedRoute,private qservice:QuestionService,
    private aservice:AnswerService,private router:Router,private loginService:LoginService) { }

qId:any;
aId:any;
user:Employee;
ans:Answer=new Answer();
query:Question=new Question();
aemp:Employee=new Employee();
qemp:Employee=new Employee();


  ngOnInit(): void {

this.aId=this.aroute.snapshot.params['aid'];
this.qId=this.aroute.snapshot.params['qid'];
this.user=this.loginService.getEmployee();

//answered emp

this.aservice.getAnsweredEmpByaId(this.aId).subscribe(
  (data:any)=>{
    console.log(data,'aemp')
this.aemp=data;
  },
  (error)=>Swal.fire('something went wrong','server error','error')
);

//view Queried emp

this.qservice.findEmployeeByQid(this.qId).subscribe(
  (data:any)=>{
    this.qemp=data;
  } ,
  (error)=>Swal.fire('Something went wrong!','Unable to fetch data','error')
  );


 // query data

  this.qservice.showQueryDetails(this.qId).subscribe(
    (data:any)=>{
      console.log(data.answers)
  this.query=data;
  
  
    },
    (error)=>Swal.fire('Something went wrong!','Unable to fetch data','error')
  );

  //get answer

  this.aservice.getAnswereByaId(this.aId).subscribe(
    (data:any)=>this.ans=data
    ,
    (error)=>Swal.fire('Something went wrong!','Unable to fetch data','error')
    
  )

  

}




//delete answer

delete(){
  if(confirm('do you want to delete')){
  this.aservice.deleteAnswerByaId(this.aId,this.qId).subscribe(
    (data:any)=>{
    Swal.fire('deleted SuccessFully!','deleted','success');
     this.router.navigate([`userDashboard/viewQuery/${this.qId}`]);
    }
   ,
   (error)=>{
    Swal.fire('Something went wrong!','not deleted','error')
  console.log(error)
   }
  )
  }
  
  }

}
