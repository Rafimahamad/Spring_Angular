import { Component, OnInit } from '@angular/core';
import { Employee } from 'src/app/classes/employee';
import { LoginService } from 'src/app/services/login.service';

@Component({
  selector: 'app-user-sidebar',
  templateUrl: './user-sidebar.component.html',
  styleUrls: ['./user-sidebar.component.css']
})
export class UserSidebarComponent implements OnInit {



  canExit(): boolean {
    if(confirm('do you want to logout ?')) {
      return true;
    }
    else{
      return false;
    }
  }

  constructor(private loginService:LoginService) { }
user:Employee=new Employee();
  ngOnInit(): void {
    this.user= this.loginService.getEmployee();
  }

  logout(){
    if(this.canExit()){
      this.loginService.logout();
    }
    else
    console.log('not loggedout')
  
  }

}
