import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Answer } from 'src/app/classes/answer';
import { Employee } from 'src/app/classes/employee';
import { Question } from 'src/app/classes/question';
import { LoginService } from 'src/app/services/login.service';
import { QuestionService } from 'src/app/services/question.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-see-query',
  templateUrl: './see-query.component.html',
  styleUrls: ['./see-query.component.css']
})
export class SeeQueryComponent implements OnInit {

  constructor(private qservice:QuestionService,private aroute:ActivatedRoute,
    private router:Router,private loginService:LoginService) { }

  query:Question=new Question();
qId:number;
qemp:any;
answers:Answer[];
user:Employee;

  ngOnInit(): void {
   this.qId= this.aroute.snapshot.params['qid'];

   this.user=this.loginService.getEmployee();
this.qservice.showQueryDetails(this.qId).subscribe(
  (data:any)=>{
    console.log(data.answers)
this.query=data;
this.answers=data.answers;

  },
  (error)=>Swal.fire('Something went wrong!','Unable to fetch data','error')
);


//view Queried emp

this.qservice.findEmployeeByQid(this.qId).subscribe(
  (data:any)=>{
    this.qemp=data;
  } ,
  (error)=>Swal.fire('Something went wrong!','Unable to fetch data','error')
  );




  }


  delete(){
    if(confirm('do you want to delete')){
     this.qservice.deleteQueryById(this.qId).subscribe(
       (data:any)=>{
         Swal.fire('deleted Successfully !','deleted','success');
   this.router.navigate([`adminDashboard/allQueries`])
       },
       (error)=>Swal.fire('something went wrong !','not deleted','error')
     );
    }
   }

}
