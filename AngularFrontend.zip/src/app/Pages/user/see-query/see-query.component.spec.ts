import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SeeQueryComponent } from './see-query.component';

describe('SeeQueryComponent', () => {
  let component: SeeQueryComponent;
  let fixture: ComponentFixture<SeeQueryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SeeQueryComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SeeQueryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
