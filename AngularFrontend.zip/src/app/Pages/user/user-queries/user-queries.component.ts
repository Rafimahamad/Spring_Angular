import { Component, OnInit } from '@angular/core';
import { Question } from 'src/app/classes/question';
import { QuestionService } from 'src/app/services/question.service';

@Component({
  selector: 'app-user-queries',
  templateUrl: './user-queries.component.html',
  styleUrls: ['./user-queries.component.css']
})
export class UserQueriesComponent implements OnInit {

  queries: Question [];
  constructor(private query:QuestionService) { }

  ngOnInit(): void {
this.query.getYourQueries().subscribe(
  (data:any)=>{
    this.queries=data;
  }
)
  }
}
