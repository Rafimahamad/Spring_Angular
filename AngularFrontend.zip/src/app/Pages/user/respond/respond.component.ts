import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Answer } from 'src/app/classes/answer';
import { AnswerService } from 'src/app/services/answer.service';
import { LoginService } from 'src/app/services/login.service';
import { QuestionService } from 'src/app/services/question.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-respond',
  templateUrl: './respond.component.html',
  styleUrls: ['./respond.component.css']
})
export class RespondComponent implements OnInit {

 
  constructor(private loginService:LoginService,private aroute:ActivatedRoute,private qservice:QuestionService
    ,private aservice:AnswerService,private router:Router) { }
user:any;
qId:any;
query:any;
spin=false;


ans:Answer=new Answer();
  ngOnInit(): void {

    this.qId= this.aroute.snapshot.params['qid'];


    this.loginService.getCurrentUser().subscribe(
      (data:any)=>this.user=data
      );


      this.qservice.showQueryDetails(this.qId).subscribe(
        (data:any)=>{
          console.log(data)
      this.query=data;
        },
        (error)=>Swal.fire('Something went wrong!','Unable to fetch data','error')
      );
  }
formSubmit(){
  this.spin=true;
 this.aservice.saveAnswer(this.ans,this.qId).subscribe(
  (data:any)=>{
  Swal.fire('Saved Successfully' ,'success','success');
  this.spin=false;
this.router.navigate([`userDashboard/viewQuery/${this.qId}`])
}

 )

}

}
