import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Employee } from 'src/app/classes/employee';
import { Question } from 'src/app/classes/question';
import { LoginService } from 'src/app/services/login.service';
import { QuestionService } from 'src/app/services/question.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-update-query',
  templateUrl: './update-query.component.html',
  styleUrls: ['./update-query.component.css']
})
export class UpdateQueryComponent implements OnInit {

 
  query:Question=new Question();
  user:Employee=new Employee();

  constructor( private loginService:LoginService,private questionService:QuestionService,
    private router:Router,private aroute:ActivatedRoute) { }

  ngOnInit(): void {
    this.user=this.loginService.getEmployee();
this.query.qId=this.aroute.snapshot.params['qid'];


this.questionService.showQueryDetails(this.query.qId).subscribe(
  (data:any)=>{
    this.query=data;
  }
);


  }



  formSubmit(){
    this.questionService.saveEditedQuery(this.query.qId  ,this.query).subscribe(
     (data:any)=>{
       Swal.fire('Saved SuccessFully !','saved','success');
      this.router.navigate([`userDashboard/allQueries`]);
     },
     (error)=>{
       Swal.fire('Something went wrong !','error','error');
 
     }
    )
   }


}
