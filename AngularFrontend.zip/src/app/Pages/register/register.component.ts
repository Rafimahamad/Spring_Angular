import { Component, OnInit } from '@angular/core';
import { Employee } from 'src/app/classes/employee';
import { EmployeeServiceService } from 'src/app/services/employee-service.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  employee:Employee=new Employee();
confirmPassword:any;
message:any;
  constructor(private empService:EmployeeServiceService) { }

  ngOnInit(): void {
  }

  newEmployee(): void {
    
    this.employee = new Employee();
  }


dList:any=[
  {value:'Associate Engineer Technology',viewValue:'Associate Engineer Technology'},
  {value:'Engineer Technology',viewValue:'Engineer Technology'},
  {value:'Associate Programmer Analyst',viewValue:'Associate Programmer Analyst'},
  {value:'Programmer Analyst',viewValue:'Programmer Analyst'},
  {value:'Associate Architect Engineer',viewValue:'Associate Architect Engineer'},
  {value:'senior Architect Engineer',viewValue:'senior Architect Engineer'},
  {value:'Engineer IT',viewValue:'Engineer IT'},
  {value:'Manager',viewValue:'Manager'},
  {value:'Others',viewValue:'Others'},

]


formSubmit(){
  console.log(this.employee.firstName+'method');
  if(this.confirmPassword!=this.employee.password){
    this.message="confim password should match with password"
   
  }
  else{
    this.empService.registerEmployee(this.employee).subscribe(
      (data:any)=>{
        Swal.fire('Registered SuccessFully !','registered','success')

      },
      error=>console.log(error)
      
    )

  }
    
  

}


}
