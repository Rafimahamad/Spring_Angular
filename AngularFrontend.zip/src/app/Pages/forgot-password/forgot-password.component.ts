import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { EmployeeServiceService } from 'src/app/services/employee-service.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {
email:String='';
valid=false;
otp:number;
otpForm=false;
change=false;
spin=false;
password:String;
confirmPassword:String;
message:String;

  constructor( private empService:EmployeeServiceService ,private arouter:ActivatedRoute,
    private router:Router) { }

  ngOnInit(): void {
  }


  getOtp(){
    this.spin=true;
    this.empService.sendOtp(this.email).subscribe(
      (data:any)=>{
        Swal.fire('we have sent 4-digit otp to your mail Id','please check your mail','info');
    this.valid=true;
        this.otpForm=true;
        this.spin=false;
      },
      (error)=>{
        this.spin=false;
          Swal.fire('mail Id not exist ','please check your mail Id','error')
       
      }
    )
  }


validateOtp(){
  this.spin=false;
  this.empService.validateOtp(this.otp).subscribe(
    (data:any)=>{
      Swal.fire('Validated Successfully !','valid','success');
    this.otpForm=true;
    this.change=true;
    this.valid=false;
    },
    error=>
    Swal.fire('Invalid Otp ','please check your mail','error')

  )
}


changePassword(){
  if(this.password!=this.confirmPassword){
    this.message="confim password should match with password"
  }
  else{
    this.empService.changeYourPassword(this.password).subscribe(
      ()=>{
        Swal.fire('Password Changed SuccessFully ! ','success',"success")
        this.router.navigate([`login`])
      },
      error=>Swal.fire('Something went wrong! ','error',"error")
    )
  }
}

}
