import { Component, OnInit } from '@angular/core';
import { Employee } from 'src/app/classes/employee';
import { EmployeeServiceService } from 'src/app/services/employee-service.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.css']
})
export class SettingsComponent implements OnInit {
employee:Employee=new Employee();
confirmPassword:any;
message:any;
  constructor(private empService:EmployeeServiceService) { }

  ngOnInit(): void {
  }

  changePassword(){
    if(this.confirmPassword!=this.employee.password){
      this.message="confim password shold match with password"
     
    }
    else{
this.empService.changePassword(this.confirmPassword).subscribe(
  (data:any)=>{
    Swal.fire('Password Changed Successfully !','success','success');
  },
  (error)=>{
    if(error.status==406)
    Swal.fire('you had already used this password !','Try new One','info')
    else
    Swal.fire('Something went wrong !','error','error')
  }
 
  
)
    }
  }

}
