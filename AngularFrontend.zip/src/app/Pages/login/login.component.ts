import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/services/login.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private loginService:LoginService, private router:Router) { }
login={
  email:'',
  password:''
}
  ngOnInit(): void {
  }


loginForm(){
console.log("submitted");
this.loginService.generateToken(this.login).subscribe(
  (data:any)=>{
    this.loginService.userLoggedIn(data.token);
    this.loginService.getCurrentUser().subscribe(
      (emp:any)=>{
        console.log(emp);
        this.loginService.setEmployee(emp);
        
        //redirect based on roles

        if(this.loginService.getEmployeeRole()=="ROLE_USER")
        {
           //this.router.navigate([`userDashboard`]);
           window.location.href='userDashboard/allQueries';
        }
    else  if(this.loginService.getEmployeeRole()=="ROLE_ADMIN")
    {
      //this.router.navigate([`adminDashboard/allQueries`]);
      window.location.href='adminDashboard/allQueries';

   } 
   else if(this.loginService.getEmployeeRole()=="BLOCK")
   {
     Swal.fire('you have Blocked By Admin','blocked','info');
     this.loginService.logout();
  }
  else{
    Swal.fire('Something went wrong','please try after sometime','info');
    this.loginService.logout();
  }

       
      },
      error=>console.log('error in current user')
    )
  },
  (error)=>{
    Swal.fire('invalid Details','try again','error');
   
  }
)
}

}
