import { Component, OnInit } from '@angular/core';
import { Question } from 'src/app/classes/question';
import { QuestionService } from 'src/app/services/question.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-un-resolved',
  templateUrl: './un-resolved.component.html',
  styleUrls: ['./un-resolved.component.css']
})
export class UnResolvedComponent implements OnInit {

  constructor( private qservice:QuestionService) { }
queries:Question[];
  ngOnInit(): void {
this.qservice.getUnREsolvedQueries().subscribe(
 ( data:any)=>
  {
    this.queries=data;
 
  },
  error=>Swal.fire('Something went wrong !','server error','error')
)

  }

}
