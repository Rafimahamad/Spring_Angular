import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UnResolvedComponent } from './un-resolved.component';

describe('UnResolvedComponent', () => {
  let component: UnResolvedComponent;
  let fixture: ComponentFixture<UnResolvedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UnResolvedComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UnResolvedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
