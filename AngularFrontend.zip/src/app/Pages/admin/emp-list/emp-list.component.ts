import { Component, OnInit } from '@angular/core';
import { Employee } from 'src/app/classes/employee';
import { EmployeeServiceService } from 'src/app/services/employee-service.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-emp-list',
  templateUrl: './emp-list.component.html',
  styleUrls: ['./emp-list.component.css']
})
export class EmpListComponent implements OnInit {

  empList:Employee[];
  spin=false;
  constructor(private empService:EmployeeServiceService) { }

  ngOnInit(): void {
   this.employeesData();

  }

employeesData(){
  this.empService.employeeList().subscribe(
    (data:any)=>{
      console.log(data)
      this.empList=data;
    },
    (error)=>Swal.fire('Something went wrong ! ','error','error')
  );
}

block(id:number){
  this.spin=true;
this.empService.blockEmployee(id).subscribe(
  (data:any)=>{
    this.spin=false;
    Swal.fire('Blocked','','info');
    this.employeesData();
   
  },
  error=>Swal.fire('Something went wrong ! ','error','error')

)



}

activate(id:number){
  this.spin=true;
this.empService.activateEmployee(id).subscribe(
  (data:any)=>{
    this.spin=false;
    Swal.fire('Activated Successfully !','Activated','success');
    this.employeesData();
  },
  error=>Swal.fire('Something went wrong ! ','error','error')
)


}

}
