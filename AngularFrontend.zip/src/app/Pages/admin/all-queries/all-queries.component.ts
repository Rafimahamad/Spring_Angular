import { Component, OnInit } from '@angular/core';
import { Question } from 'src/app/classes/question';
import { QuestionService } from 'src/app/services/question.service';

@Component({
  selector: 'app-all-queries',
  templateUrl: './all-queries.component.html',
  styleUrls: ['./all-queries.component.css']
})
export class AllQueriesComponent implements OnInit {

question:any;
  queries: Question[]
  constructor(private query:QuestionService) { }

  ngOnInit(): void {
this.query.getAllQuestions().subscribe(
  (data:any)=>{
    this.queries=data;
  }
)
  }



  // search

  search(){
    if(this.question==""){
      this.ngOnInit();
    }
    else{
      this.queries=this.queries.filter(
        (result:any)=>{
          return result.question.toLocaleLowerCase().match(this.question.toLocaleLowerCase());
        }
      )
    }
  }

}
