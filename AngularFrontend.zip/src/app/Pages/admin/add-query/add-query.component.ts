import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from 'src/app/classes/employee';
import { Question } from 'src/app/classes/question';
import { LoginService } from 'src/app/services/login.service';
import { QuestionService } from 'src/app/services/question.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-add-query',
  templateUrl: './add-query.component.html',
  styleUrls: ['./add-query.component.css']
})
export class AddQueryComponent implements OnInit {

  query:Question=new Question();
  user:Employee=new Employee();
  constructor( private loginService:LoginService,private questionService:QuestionService,
    private router:Router) { }

  ngOnInit(): void {
this.user=this.loginService.getEmployee();

  }

  formSubmit(){
   this.questionService.saveQuery(this.query).subscribe(
    (data:any)=>{
      Swal.fire('Saved SuccessFully !','saved','success');
     this.router.navigate([`adminDashboard/allQueries`]);
    },
    (error)=>{
      Swal.fire('Something went wrong !','error','error');

    }
   )
  }

}
