import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from 'src/app/classes/employee';
import { EmployeeServiceService } from 'src/app/services/employee-service.service';
import { LoginService } from 'src/app/services/login.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-update-profile',
  templateUrl: './update-profile.component.html',
  styleUrls: ['./update-profile.component.css']
})
export class UpdateProfileComponent implements OnInit {

  constructor(  private loginService:LoginService,private empService:EmployeeServiceService,private router:Router  ) { }
employee:Employee=new Employee();


  dList:any=[
    {value:'Associate Engineer Technology',viewValue:'Associate Engineer Technology'},
    {value:'Engineer Technology',viewValue:'Engineer Technology'},
    {value:'Associate Programmer Analyst',viewValue:'Associate Programmer Analyst'},
    {value:'Programmer Analyst',viewValue:'Programmer Analyst'},
    {value:'Associate Architect Engineer',viewValue:'Associate Architect Engineer'},
    {value:'senior Architect Engineer',viewValue:'senior Architect Engineer'},
    {value:'Engineer IT',viewValue:'Engineer IT'},
    {value:'Manager',viewValue:'Manager'},
    {value:'Others',viewValue:'Others'},
  
  ]

  ngOnInit(): void {
    this.loginService.getCurrentUser().subscribe(
      (data:any)=>{
        this.employee=data;
        console.log(data);

      }
    )
  }

formSubmit(){

this.empService.saveProfile(this.employee).subscribe(
(data:any)=>{
  Swal.fire('updated Successfully !','success','success');
this.router.navigate([`adminDashboard/profile`])
},
(error)=>Swal.fire('Something went wrong !','not updated !','error')
)
  
}

}
