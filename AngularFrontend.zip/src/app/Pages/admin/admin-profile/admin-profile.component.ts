import { Component, OnInit } from '@angular/core';
import { Employee } from 'src/app/classes/employee';
import { LoginService } from 'src/app/services/login.service';

@Component({
  selector: 'app-admin-profile',
  templateUrl: './admin-profile.component.html',
  styleUrls: ['./admin-profile.component.css']
})
export class AdminProfileComponent implements OnInit {

  constructor( private loginService:LoginService) { }
user:Employee=new Employee();
  ngOnInit(): void {
this.loginService.getCurrentUser().subscribe(
  (data:any)=>{
    this.user=data;
    
  }
)

  }


}
