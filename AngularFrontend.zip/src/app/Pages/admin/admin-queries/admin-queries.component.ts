import { Component, OnInit } from '@angular/core';
import { Question } from 'src/app/classes/question';
import { QuestionService } from 'src/app/services/question.service';

@Component({
  selector: 'app-admin-queries',
  templateUrl: './admin-queries.component.html',
  styleUrls: ['./admin-queries.component.css']
})
export class AdminQueriesComponent implements OnInit {

  queries: Question [];
  constructor(private query:QuestionService) { }

  ngOnInit(): void {
this.query.getYourQueries().subscribe(
  (data:any)=>{
    this.queries=data;
  }
)
  }
}
