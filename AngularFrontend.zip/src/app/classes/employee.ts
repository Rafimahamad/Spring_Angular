export class Employee {

    id: number;
    firstName: String;
    lastName: String;
    role: String;
    email: String;
    doj: String;
    gender: String;
    phoneNo: String;
    designation: String;
    password: String;
    profile:String;

}
