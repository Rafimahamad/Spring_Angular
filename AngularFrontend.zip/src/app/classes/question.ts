export class Question {
    qId:number;
    question:String;
    date:String;
}
