export class Answer {
    aId:number;
    answer:String;
    date:String;
    

}
